lloyds_df <- read.csv("Lloyds_r.csv")
samp_size <- nrow(lloyds_df)
spent <- lloyds_df$Amount.Spent
xbar <- mean(spent)
sigma <- 20
cl  <- c(0.90, 0.95, 0.99)
alpha <-  1-cl
error <- qnorm(1-alpha/2)*sigma/sqrt(samp_size)
ub <- xbar+error
lb <- xbar-error
for( i in 1:length(cl) ){
  cat(cl[i]*100, "% Confidence Level: [", lb[i], ",", ub[i], "]\n")
}

          