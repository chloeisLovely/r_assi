mu <- 20
sigma <- 4
x <- seq(from = 0, to = 40,length.out = 101)
y <- dnorm(x, mean = mu, sd = sigma)
plot(x,y,type = 'l')
cum <- pnorm(x, mean = mu, sd = sigma)
plot(x,cum,type = 'l')


