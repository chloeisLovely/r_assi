new_balance_df <- read.csv("newbalance_r.csv")
samp_size <- nrow(new_balance_df)
balance <- new_balance_df$NewBalance
xbar <- mean(balance)
s <- sd(balance)
cl  <- c(0.90, 0.95, 0.99)
alpha <-  1-cl
error <- qt(1-alpha/2, df = samp_size-1)*s/sqrt(samp_size)
ub <- xbar+error
lb <- xbar-error
for( i in 1:length(cl) ){
  cat(cl[i]*100, "% Confidence Level: [", lb[i], ",", ub[i], "]\n")
}
