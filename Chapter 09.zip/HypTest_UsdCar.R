alpha <- 0.05
df <- read.csv("usedcars2022.csv")
n <- nrow(df)

pr <- df$Sale.Price
xbar <- mean(pr)
s<-sd(pr)
cat("sample mean (xbar) = ", xbar)
cat("\n")
cat("sample stdev (s) = ", s)
cat("\n")

mu0  <- 27569

tst <- (xbar-mu0)/(s/sqrt(n))
pvalue <- 2*pt(-abs(tst), df = n-1) #upper tailed test
cat("p-vales = ", pvalue)
cat("\n")
if (pvalue>alpha){
  cat("H0 is not rejected.\n")
} else {
  cat("H0 is rejected.\n")
}

talpha2 <- qt(1-alpha/2, df = n-1)
cat("test statistic t = ", tst)
cat("\n")
cat("Critical value t(alpha/2)", talpha2)
cat("\n")
if( abs(tst)<talpha2 ){
  cat("H0 is not rejected\n")
} else {
  cat("we reject H0\n")
}