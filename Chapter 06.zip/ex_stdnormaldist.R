mu <- 60000
sigma <- 8000
tirelif <- 65000
z <- (tirelif-mu)/sigma
P <- pnorm(z, mean = 0, sd = 1) #P(x<65000)
Q <- 1-P #P(x>65000)
cat("P(x>65000)=",Q, "\n")

z_st <- qnorm(0.10, mean = 0, sd = 1)
x_st <- mu+sigma*z_st
cat("x* such that P(x<x*)=0.10 is", x_st, "\n")