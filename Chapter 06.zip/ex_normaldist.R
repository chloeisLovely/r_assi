mu <- 60000
sigma <- 8000
tirelif <- 65000
P <- pnorm(tirelif, mean = mu, sd = sigma) #P(x<65000)
Q <- 1-P #P(x>65000)
cat("P(x>65000)=",Q, "\n")

x_st <- qnorm(0.10, mean = mu, sd = sigma)
cat("x* such that P(x<x*)=0.10 is", x_st, "\n")