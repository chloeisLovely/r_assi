alpha <- 0.05
df <- read_csv("fowle.csv")
n <- nrow(df)
xbar <- mean(df$Time)
cat("sample mean (xbar) = ", xbar)
cat("\n")
mu0  <- 15
sigma <- 4
z <- (xbar-mu0)/(sigma/sqrt(n))
pvalue <- 1-pnorm(z) #upper tailed test
cat("p-vales = ", pvalue)
cat("\n")
if (pvalue>alpha){
  cat("H0 is not rejected.\n")
} else {
  cat("H0 is rejected.\n")
}

zalpha <- qnorm(1-alpha)
cat("test statistic z = ", z)
cat("\n")
cat("Critical value z(alpha)", zalpha2)
cat("\n")
if( z<zalpha ){
  cat("H0 is not rejected\n")
} else {
  cat("we reject H0\n")
}
